package model;

public enum Race {
	Humain, Elfe, Nain, Halfelin, Gnome, Tieffelin;
}
