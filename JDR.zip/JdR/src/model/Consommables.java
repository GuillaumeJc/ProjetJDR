package model;

public class Consommables extends Stuff {

private String description;

	public Consommables(String libelle,String description) {
		super(libelle);
		this.description = description;
	}
	
	
	
	
}



