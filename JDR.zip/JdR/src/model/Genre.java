package model;

public enum Genre {

	Femme,Homme,NB;
}
