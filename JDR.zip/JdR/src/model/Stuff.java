package model;

public abstract class Stuff {

	protected String libelle;
	protected int id;
	protected int prix;
	
	
	public Stuff(String libelle, int id) {
		this.libelle = libelle;
	}




}
