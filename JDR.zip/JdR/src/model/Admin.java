package model;

public class Admin extends Compte {

	public Admin(String login, String password) {
		super(login, password);
		// TODO Auto-generated constructor stub
	}



}
