package model;

public class Emplacement {

}
