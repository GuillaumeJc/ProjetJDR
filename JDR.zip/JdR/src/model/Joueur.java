package model;

public class Joueur extends Compte {

	public Joueur(String login, String password) {
		super(login, password);
		// TODO Auto-generated constructor stub
	}

}
