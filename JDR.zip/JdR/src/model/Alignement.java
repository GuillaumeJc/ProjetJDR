package model;

public enum Alignement {
	
	LoyalBon, NeutreBon, ChaotiqueBon, LoyalNeutre, Neutre, ChaotiqueNeutre, LoyalMauvais, NeutreMauvais, ChaotiqueMauvais;
	
}
