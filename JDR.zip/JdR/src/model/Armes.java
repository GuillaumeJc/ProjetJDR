package model;

public class Armes extends Stuff {


private int arme;
private Caracteristiques carac;
private int bonus;


	public void Armes(String libelle,String description, int boost) {
		super(libelle,id);
	}

}
