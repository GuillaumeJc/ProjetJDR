package model;

public class Metier {

	private String libelle; 
	
	
	
}
