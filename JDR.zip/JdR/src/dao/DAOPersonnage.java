package dao;

public class DAOPersonnage {

}
