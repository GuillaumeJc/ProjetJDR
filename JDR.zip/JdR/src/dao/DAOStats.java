package dao;

public class DAOStats {

}
